import java.util.Scanner;

public class Main {
    //Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
    //
    //
    //умножить число на 2, если оно нечётное;
    //
    //прибавить к числу 5, если если оно заканчивается на 5 или 0.
    //Если число < 0, то взять его по модулю и разделить на 3.
    //Результат вычисления вывести в консоль.
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Geben Sie die Zahl ein: ");
        int zahl = scr.nextInt();
        if (zahl > 0 && zahl % 2 != 0){
            System.out.println(zahl * 2);
        }
        if ((zahl % 10 == 5 || zahl % 10 == 0) && zahl > 0){
            System.out.println(zahl +5);
        }
            if (zahl < 0){
                System.out.println(Math.abs(zahl) / 3);
            }



    }
}