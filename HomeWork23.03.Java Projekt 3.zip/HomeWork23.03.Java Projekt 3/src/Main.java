import java.util.Scanner;

public class Main {

    //Пользователь вводит два числа. Если они не равны, то вывести в консоль их сумму, иначе вывести их произведение.
    // Используйте тернарный оператор.
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println(" Geben Sie bitte 2 Zahle ein: ");
        int zahl = scr.nextInt();
        int zahl1 = scr.nextInt();
        if (zahl != zahl1){
            System.out.println("Die Summe der ungleiche Zahle ist: " + (zahl + zahl1));
        }
        else{
            System.out.println(" Die Multiplikation von der gleiche Zahle ist: " + zahl * zahl1);
        }

    }
}