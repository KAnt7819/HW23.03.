import java.util.Random;

public class Main {
    //С помощью Random сгенерируйте три числа. Напишите программу, которая находит максимальное из них.
    // Используйте тернарные операторы.
    public static void main(String[] args) {


        Random rm = new Random();
        int Zahl1 = rm.nextInt();
        int Zahl2 = rm.nextInt();
        int Zahl3 = rm.nextInt();
        System.out.println("Zahl1 " + Zahl1 + " Zahl2 " + Zahl2 + " Zahl3 " + Zahl3);
        if (Zahl1 >= Zahl2 && Zahl1 >= Zahl3) {
            System.out.println(Zahl1);
        }
        if (Zahl2 >= Zahl1 && Zahl2 >= Zahl3) {
            System.out.println(Zahl2);
        }
        if (Zahl3 >= Zahl2 && Zahl3 >= Zahl1) {
            System.out.println(Zahl3);
        }
    }
}
