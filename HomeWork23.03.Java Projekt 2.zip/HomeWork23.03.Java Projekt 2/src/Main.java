import java.util.Scanner;

public class Main {
//Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),
// то вывести эту цифру в консоль. Если строка начинается со знака _ или знака -, то вывести в консоль строку без этого знака.
// Используйте методы startsWith, charAt и substring.

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Geben Sie die Zahlenlinie ein: ");
        String linie = scr.next();
        if (linie.charAt(0) == '0' || linie.charAt(0) == '1' || linie.charAt(0) == '2' || linie.charAt(0) == '3' || linie.charAt(0) == '5'
                || linie.charAt(0) == '6' || linie.charAt(0) == '7' || linie.charAt(0) == '8' || linie.charAt(0) == '9' || linie.charAt(0) == '4'){
            System.out.println(linie.charAt(0));
        }
        if (linie.startsWith("_") || linie.startsWith("-")) {
            System.out.println(linie.substring(1));
        }
    }
}